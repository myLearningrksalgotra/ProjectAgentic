import { G, f } from "./mermaid-parser.core.8iL3vDHX.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};

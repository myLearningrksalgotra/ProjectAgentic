import { I, c } from "./mermaid-parser.core.8iL3vDHX.js";
export {
  I as InfoModule,
  c as createInfoServices
};

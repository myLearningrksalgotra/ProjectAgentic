import { P, a } from "./mermaid-parser.core.8iL3vDHX.js";
export {
  P as PacketModule,
  a as createPacketServices
};

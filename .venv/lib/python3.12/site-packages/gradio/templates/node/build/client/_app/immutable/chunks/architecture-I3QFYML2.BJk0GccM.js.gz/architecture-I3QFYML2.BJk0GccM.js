import { A, e } from "./mermaid-parser.core.8iL3vDHX.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
